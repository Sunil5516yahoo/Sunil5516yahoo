﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SiemensAudiology;

namespace UnitTestSiemenProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodtoLoginSuccess()
        {
            JewelryShopProgram objJewelryShopProgram = JewelryShopProgram.login("test", "test");
            Assert.IsNotNull(objJewelryShopProgram);
        }

        [TestMethod]
        public void TestMethodtoLoginFailure()
        {
            JewelryShopProgram objJewelryShopProgram = JewelryShopProgram.login("test", "test1");
            Assert.IsNull(objJewelryShopProgram);
        }

        [TestMethod]
        public void TestMethodtoCalcGold_only_When_LoginSuccess()
        {
            double totalprice = 9500;
            JewelryShopProgram objJewelryShopProgram = JewelryShopProgram.login("test", "test");
            Assert.IsNotNull(objJewelryShopProgram);
            Assert.AreEqual(totalprice, objJewelryShopProgram.calculateGold(1000, 10, 5));
        }
    }
}
