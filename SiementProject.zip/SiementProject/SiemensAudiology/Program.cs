﻿using System;

namespace SiemensAudiology
{
    public class JewelryShopProgram
    {
        private static JewelryShopProgram instace_JewelryShopProgram = null;
        private JewelryShopProgram()
        {

        }

        public static void Main(string[] args)
        {
            string username = "", password = "";
            bool successfull = false, isConverted = false;
            double goldWeight, percentage, goldPrice_perGram = 1000;

            Console.Write("To login please ");

            while (!successfull)
            {

                Console.WriteLine("enter your username:");
                username = Console.ReadLine();
                Console.WriteLine("enter your password:");

                password = passwordMethod();


                if (login(username, password) != null)
                {

                    Console.WriteLine("Gold price per gram {0} rupees.", goldPrice_perGram);

                    do
                    {
                        Console.WriteLine("Please enter weight of the gold");
                        isConverted = double.TryParse(Console.ReadLine(), out goldWeight);

                    } while (!isConverted);


                    do
                    {
                        Console.WriteLine("Please enter discount percentage if required");
                        string percentagedata = Console.ReadLine();
                        if (string.IsNullOrWhiteSpace(percentagedata))
                        {
                            percentagedata = "0";
                        }
                        isConverted = double.TryParse(percentagedata, out percentage);

                    } while (!isConverted);
                    Console.WriteLine("Total value of gold is {0}", instace_JewelryShopProgram.calculateGold(goldPrice_perGram, goldWeight, percentage));
                    Console.WriteLine("Thank you for shopping with us.");
                    Console.ReadKey();
                    break;
                }

                if (!successfull)
                {
                    Console.WriteLine("Your username or password is incorect, try again !!!");
                }
            }
        }


        public static JewelryShopProgram login(string userName, string password)
        {
            var arrUsers = new Users[]
            {
            new Users("siemen","technology"),
            new Users("test","test"),
            new Users("dotnet","dotnet")
            };

            foreach (Users user in arrUsers)
            {
                if (userName == user.username && password == user.password && instace_JewelryShopProgram == null)
                {
                    return instace_JewelryShopProgram = new JewelryShopProgram();
                }
            }

            return instace_JewelryShopProgram;

        }

        private static string passwordMethod()
        {
            ConsoleKeyInfo key;
            string password = "";
            do
            {
                key = Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.WriteLine();
                    break;
                }
                else if (key.Key != ConsoleKey.Backspace)
                {
                    password += key.KeyChar;
                    Console.Write("*");
                }
                else if (password.Length > 0)
                {
                    password = password.Substring(0, password.Length - 1);
                    Console.Write("\b \b");
                }

            } while (key.Key != ConsoleKey.Enter);

            return password;
        }

        public double calculateGold(double goldPrice_perGram, double goldWeight, double percentage)
        {
            double goldTotalPrice;

            goldTotalPrice = goldPrice_perGram * goldWeight;

            if (percentage > 0)
            {
                goldTotalPrice -= goldTotalPrice * percentage / 100;
            }
            return goldTotalPrice;
        }
    }
}

public class Users
{
    public string username;
    public string password;

    public Users(string username, string password)
    {

        this.username = username;
        this.password = password;
    }
}